repo: nono84250-sudo/mchub
branch: master

## Last sync
date: 2026-09-21T21:39:39Z
commit: c7ed3a0a58c6
### Updated in this project
- Read site/src app, components, and lib for real screen structure and copy (Nav, dashboard, servers directory, manage console, forms, auth)
- Read launcher/src/index.html (Electron desktop app UI: titlebar, sidebar, server grid/detail, settings, playbar)
- Built 6 website mockup screens in Omniscient UI Mockups.dc.html, and 4 desktop-launcher mockup screens in Omniscient Launcher UI Mockups.dc.html — both styled with the Nocturne design system

## Screen map
| Screen | Repo files |
| --- | --- |
| Login / Signup | site/src/app/login, site/src/app/signup, site/src/components/LoginForm.tsx, SignupForm.tsx |
| Onboarding (list your server) | site/src/components/ServerForm.tsx, site/src/app/dashboard/servers/new |
| Home / Dashboard | site/src/app/dashboard/page.tsx |
| Search (directory) | site/src/app/servers/page.tsx, site/src/components/ServerCard.tsx, ServerStatus.tsx |
| Settings (manage console) | site/src/app/manage/[id]/settings/page.tsx, ServerForm.tsx, ManageSidebar.tsx, ManageActions.tsx |
| Profile | site/src/components/AccountMenu.tsx (inferred account screen, no dedicated repo route) |
| Launcher — Login gate | launcher/src/index.html (#gate) |
| Launcher — Server list | launcher/src/index.html (#app, #sidebar, #list, #playbar) |
| Launcher — Server detail | launcher/src/index.html (#detail) |
| Launcher — Settings | launcher/src/index.html (#settings-panel) |
| Launcher — Bootstrap/splash | new screen, no repo counterpart (confirmed no splash/loading screen exists in launcher/src) |
